
  Difficulty:
Hard - Requires high technical knowledge to fix.
Moderate - Requires some technical knowledge to fix.
Easy - Requires little technical knowledge to fix.
  SEO Impact:
High - Critical issues that must be fixed. They have the greatest effect on traffic and rankings.
Medium - Issues that affect traffic and rankings, but are not putting a website in critical SEO danger.
Low - Recommended fixes based on best practices. They have the least effect on traffic and rankings.
1. Problem: With duplicate meta descriptions
Report file: duplicate_meta_descriptions.csv
Description: Meta descriptions are the small blurbs you see in search results under the page titles. These give a quick description of what the content on the page is about. These descriptions help both the people searching and the search engine crawlers understand what to expect on each page.

Avoiding duplicate meta descriptions is important as it ensures visitors will be accessing unique information. Having duplicate meta descriptions can make the ranking process more difficult as engine crawlers will have a hard time figuring out the differences between pages and what should rank and what shouldn't.
Solution: Make sure that every page you post on your website has a meta description that is both relevant to the content on the page and one of a kind.

To learn more about how to write amazing meta descriptions that are both unique and compelling, check out {0} article.
Difficulty: Moderate
SEO Impact: High
Columns:
    1. URL
    2. Have meta description duplicates
2. Problem: With duplicate <title> tags
Report file: duplicate_title_tags.csv
Description: It's very important that each of your pages have original and unique title tags. Duplicate title tags can make it more complicated to rank content in search results because search engine crawlers won't know which post to rank above the other. If you want to rank your pages without confusion or without having them compete with one another, creating unique and relevant title tags is incredibly important.
Solution: Go through your pages and make sure that all of the title tags are unique and that you don't have any duplicate title tags.

To learn more about creating SEO-friendly title tags, check out {0} article.
Difficulty: Moderate
SEO Impact: High
Columns:
    1. URL
    2. Have title duplicates
5. Problem: With a <title> tag that is too long
Report file: title_tag_too_long.csv
Description: It is recommended to keep your title tag under 65 characters so you don't run the risk of having part of it cut out from the search results page.

To learn more about creating SEO-friendly title tags, check out {0} article.
Solution: Go through your pages and shorten any of your title tags that exceed 65 characters.
Difficulty: Easy
SEO Impact: Medium
Columns:
    1. URL
    2. Title long
6. Problem: With a poorly formatted URL for SEO
Report file: seo_non_friendly_url.csv
Description: In order to create a URL that is truly SEO-friendly, one must take into account certain factors that Google deems important for rankings. Some of these factors include the length of the URL not exceeding 120 characters, how relevant the wording in the title is to the content in the post, avoiding symbols and underscores within the slug, inclusion of session IDs, too many different sub-folders, and so on.

To learn more about SEO-friendly URLs, check out {0} article.
Solution: Avoid overcomplicating your URL structure by only focusing on using keywords in your slug that are relevant to the content in the post. Your URL should only contain numbers, letters, and dashes, and you should avoid using extraneous characters such as: !, @, #, $, %, ^, &, *, (, ), [, ], ?, {, }, ;, :, “.
Difficulty: Easy
SEO Impact: Medium
Columns:
    1. URL
    2. Seo friendly url
7. Problem: Keywords check
Report file: seo_friendly_url_keywords_check.csv
Description: <b>Keywords Check</b> - This test will be looking for the consistency of page URL with meta tag keywords. If the keywords tag is empty or absent then the URL is being compared with the content of &lt;title&gt; tag.
Difficulty: Easy
SEO Impact: Medium
Columns:
    1. URL
    2. Seo friendly url keywords check
